import { IAuthStorage, authStorage } from "./replit_integrations/auth/storage";
import { IChatStorage, chatStorage } from "./replit_integrations/chat/storage";

export interface IStorage extends IAuthStorage, IChatStorage {}

export const storage: IStorage = {
  ...authStorage,
  ...chatStorage,
};
