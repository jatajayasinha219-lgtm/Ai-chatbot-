## Packages
react-markdown | Rendering AI responses with markdown support
react-syntax-highlighter | Code highlighting for AI code blocks
framer-motion | Smooth animations for chat bubbles and transitions
remark-gfm | GitHub Flavored Markdown support (tables, etc.)
date-fns | Date formatting for chat history

## Notes
Backend provides SSE streaming at /api/conversations/:id/messages
File uploads use the 2-step presigned URL flow via use-upload.ts
Auth uses Replit Auth (window.location.href = "/api/login")
