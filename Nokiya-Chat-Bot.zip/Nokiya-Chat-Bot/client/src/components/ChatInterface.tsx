import { useState, useRef, useEffect } from "react";
import { useChatStream, useGenerateImage } from "@/hooks/use-chat";
import { useAuth } from "@/hooks/use-auth";
import { useUpload } from "@/hooks/use-upload";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, SendHorizontal, Paperclip, Image as ImageIcon, Sparkles } from "lucide-react";
import { MarkdownRenderer } from "./MarkdownRenderer";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface Message {
  id: number;
  role: "user" | "assistant" | "model";
  content: string;
  createdAt: string;
}

interface ChatInterfaceProps {
  conversationId: number;
  initialMessages: Message[];
}

export function ChatInterface({ conversationId, initialMessages }: ChatInterfaceProps) {
  const [input, setInput] = useState("");
  const { sendMessage, isStreaming, streamedContent } = useChatStream(conversationId);
  const { user } = useAuth();
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Image Generation
  const generateImageMutation = useGenerateImage();
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);

  // File Upload
  const { uploadFile, isUploading } = useUpload({
    onSuccess: (res) => {
      setInput((prev) => prev + `\n[File uploaded: ${res.metadata.name}] `);
    },
    onError: (err) => {
      console.error("Upload error:", err);
    }
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      await uploadFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isStreaming) return;
    
    // Check for image generation command
    if (input.toLowerCase().startsWith("/image") || input.toLowerCase().startsWith("generate image")) {
      const prompt = input.replace(/^\/image|generate image/i, "").trim();
      if (prompt) {
        setInput("");
        try {
          const res = await generateImageMutation.mutateAsync(prompt);
          setGeneratedImage(`data:${res.mimeType};base64,${res.b64_json}`);
        } catch (error) {
          // Error handled by mutation
        }
        return;
      }
    }

    await sendMessage(input);
    setInput("");
  };

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [initialMessages, streamedContent, generatedImage]);

  return (
    <div className="flex flex-col h-full bg-background relative overflow-hidden">
      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 scroll-smooth"
      >
        <AnimatePresence initial={false}>
          {initialMessages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex w-full gap-4 max-w-4xl mx-auto",
                msg.role === "user" ? "flex-row-reverse" : "flex-row"
              )}
            >
              <Avatar className="w-10 h-10 border-2 border-border shadow-sm shrink-0">
                {msg.role === "user" ? (
                  <>
                    <AvatarImage src={user?.profileImageUrl || undefined} />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {user?.firstName?.[0] || "U"}
                    </AvatarFallback>
                  </>
                ) : (
                  <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
                    <Sparkles size={18} />
                  </AvatarFallback>
                )}
              </Avatar>

              <div className={cn(
                "flex flex-col gap-1 min-w-0 max-w-[85%]",
                msg.role === "user" ? "items-end" : "items-start"
              )}>
                <div className={cn(
                  "px-5 py-3.5 rounded-2xl shadow-sm break-words w-full",
                  msg.role === "user" 
                    ? "bg-primary text-primary-foreground rounded-br-none" 
                    : "bg-secondary/50 border border-border/50 text-foreground rounded-bl-none"
                )}>
                  {msg.role === "user" ? (
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  ) : (
                    <MarkdownRenderer content={msg.content} />
                  )}
                </div>
                <span className="text-xs text-muted-foreground px-1">
                  {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Streaming Message */}
        {isStreaming && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex w-full gap-4 max-w-4xl mx-auto"
          >
            <Avatar className="w-10 h-10 border-2 border-border shadow-sm shrink-0">
              <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
                <Sparkles size={18} className="animate-pulse" />
              </AvatarFallback>
            </Avatar>
            <div className="bg-secondary/50 border border-border/50 text-foreground px-5 py-3.5 rounded-2xl rounded-bl-none w-full max-w-[85%] shadow-sm">
              <MarkdownRenderer content={streamedContent} />
              <span className="inline-block w-2 h-4 ml-1 align-middle bg-primary animate-pulse" />
            </div>
          </motion.div>
        )}

        {/* Generated Image Display */}
        {generatedImage && (
           <motion.div 
             initial={{ opacity: 0, scale: 0.9 }}
             animate={{ opacity: 1, scale: 1 }}
             className="flex w-full gap-4 max-w-4xl mx-auto"
           >
             <Avatar className="w-10 h-10 border-2 border-border shadow-sm shrink-0">
               <AvatarFallback className="bg-gradient-to-br from-pink-500 to-orange-500 text-white">
                 <ImageIcon size={18} />
               </AvatarFallback>
             </Avatar>
             <div className="space-y-2">
               <div className="rounded-xl overflow-hidden border border-border shadow-lg">
                 <img src={generatedImage} alt="Generated AI" className="max-w-md w-full h-auto" />
               </div>
               <p className="text-xs text-muted-foreground">Generated by Gemini Image Model</p>
             </div>
           </motion.div>
        )}
        
        {/* Loading Indicator for Image Generation */}
        {generateImageMutation.isPending && (
           <div className="flex w-full justify-center py-4">
             <div className="flex items-center gap-2 text-muted-foreground bg-secondary/50 px-4 py-2 rounded-full text-sm">
               <Loader2 className="w-4 h-4 animate-spin" />
               Generating image...
             </div>
           </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-4 bg-background/80 backdrop-blur-lg border-t border-border z-10">
        <div className="max-w-4xl mx-auto relative">
          <form onSubmit={handleSubmit} className="relative flex items-end gap-2 p-2 bg-secondary/40 border border-white/10 rounded-3xl shadow-lg focus-within:ring-2 focus-within:ring-primary/50 focus-within:border-primary transition-all duration-300">
            
            {/* File Upload Button */}
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              onChange={handleFileUpload}
            />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="rounded-full h-10 w-10 text-muted-foreground hover:text-primary hover:bg-primary/10 shrink-0 mb-0.5"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading || isStreaming}
            >
              {isUploading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Paperclip className="h-5 w-5" />}
            </Button>

            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={isUploading ? "Uploading..." : "Ask ID NOKIYA AI anything..."}
              className="flex-1 bg-transparent border-none focus-visible:ring-0 focus-visible:ring-offset-0 px-2 py-3 h-auto min-h-[44px] max-h-32 resize-none text-base placeholder:text-muted-foreground/50"
              disabled={isUploading || isStreaming}
            />

            <Button 
              type="submit" 
              size="icon"
              disabled={!input.trim() || isStreaming || isUploading}
              className="rounded-full h-10 w-10 shrink-0 mb-0.5 bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 transition-opacity shadow-md shadow-primary/20"
            >
              {isStreaming ? (
                <div className="w-2 h-2 bg-white rounded-full animate-ping" />
              ) : (
                <SendHorizontal className="h-5 w-5" />
              )}
            </Button>
          </form>
          <div className="text-center mt-2">
             <p className="text-[10px] text-muted-foreground/40 font-mono">ID NOKIYA AI can make mistakes. Consider checking important information.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
