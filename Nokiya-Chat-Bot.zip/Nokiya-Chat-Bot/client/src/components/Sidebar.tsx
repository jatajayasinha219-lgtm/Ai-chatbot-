import { useConversations, useCreateConversation, useDeleteConversation } from "@/hooks/use-chat";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, MessageSquare, Trash2, LogOut, X, Menu, Box } from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import { SocialLinks } from "./SocialLinks";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Sidebar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  
  return (
    <>
      {/* Mobile Trigger */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden fixed top-3 left-3 z-50">
            <Menu />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 w-80 bg-card border-r border-border/50">
          <SidebarContent onClose={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-80 h-screen flex-col bg-card border-r border-border/50">
        <SidebarContent />
      </div>
    </>
  );
}

function SidebarContent({ onClose }: { onClose?: () => void }) {
  const { data: conversations, isLoading } = useConversations();
  const { mutate: createConversation, isPending: isCreating } = useCreateConversation();
  const { mutate: deleteConversation } = useDeleteConversation();
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();

  // Sort conversations by date (newest first)
  const sortedConversations = conversations?.sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  const handleNewChat = () => {
    createConversation("New Chat", {
      onSuccess: (newConv) => {
        setLocation(`/chat/${newConv.id}`);
        onClose?.();
      }
    });
  };

  return (
    <div className="flex flex-col h-full bg-card/50 backdrop-blur-xl">
      {/* Header */}
      <div className="p-4 border-b border-white/5">
        <Link href="/" className="flex items-center gap-3 px-2 mb-6 group cursor-pointer" onClick={onClose}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-all duration-300">
             <Box className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="font-display font-bold text-lg tracking-tight leading-none bg-clip-text text-transparent bg-gradient-to-r from-white to-white/70">
              ID NOKIYA AI
            </h1>
            <span className="text-xs text-muted-foreground font-mono">Premium Chat</span>
          </div>
        </Link>
        
        <Button 
          onClick={handleNewChat} 
          disabled={isCreating}
          className="w-full justify-start gap-2 bg-white/5 hover:bg-white/10 border border-white/5 text-foreground shadow-none h-11 rounded-xl"
        >
          <Plus className="w-5 h-5 text-primary" />
          <span className="font-medium">New Chat</span>
        </Button>
      </div>

      {/* Conversation List */}
      <ScrollArea className="flex-1 px-3 py-4">
        <div className="space-y-1">
          {isLoading ? (
            <div className="space-y-2 p-2">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-10 bg-white/5 rounded-lg animate-pulse" />
              ))}
            </div>
          ) : sortedConversations?.length === 0 ? (
            <div className="text-center text-muted-foreground text-sm py-10 px-4">
              <p>No chats yet.</p>
              <p className="text-xs mt-1 opacity-50">Start a new conversation to begin.</p>
            </div>
          ) : (
            sortedConversations?.map((conv) => {
              const isActive = location === `/chat/${conv.id}`;
              return (
                <div
                  key={conv.id}
                  className={cn(
                    "group flex items-center justify-between gap-2 px-3 py-3 rounded-lg text-sm transition-all duration-200 cursor-pointer border border-transparent",
                    isActive 
                      ? "bg-primary/10 text-primary border-primary/20 font-medium" 
                      : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                  )}
                  onClick={() => {
                    setLocation(`/chat/${conv.id}`);
                    onClose?.();
                  }}
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <MessageSquare size={16} className={cn("shrink-0", isActive ? "text-primary" : "opacity-50")} />
                    <span className="truncate">{conv.title}</span>
                  </div>
                  
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteConversation(conv.id);
                      if (isActive) setLocation("/");
                    }}
                    className="opacity-0 group-hover:opacity-100 p-1.5 hover:bg-red-500/10 hover:text-red-400 rounded-md transition-all"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              );
            })
          )}
        </div>
      </ScrollArea>

      {/* Footer */}
      <div className="border-t border-white/5 bg-black/20">
        <SocialLinks />
        
        <div className="p-4 pt-0">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
            <Avatar className="h-9 w-9 border border-white/10">
              <AvatarImage src={user?.profileImageUrl || undefined} />
              <AvatarFallback>{user?.firstName?.[0] || "U"}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user?.firstName || "User"}</p>
              <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => logout()}
              className="h-8 w-8 hover:bg-white/10 hover:text-red-400 rounded-lg"
              title="Logout"
            >
              <LogOut size={16} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
