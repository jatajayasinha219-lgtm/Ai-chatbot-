import { Youtube, Send, Instagram } from "lucide-react";
import { motion } from "framer-motion";

export function SocialLinks() {
  return (
    <div className="flex gap-4 items-center justify-center p-4">
      <motion.a
        href="https://youtube.com"
        target="_blank"
        rel="noopener noreferrer"
        whileHover={{ scale: 1.1, y: -2 }}
        whileTap={{ scale: 0.95 }}
        className="p-3 rounded-full bg-red-600 text-white shadow-lg shadow-red-600/20 hover:shadow-red-600/40 transition-all"
        title="YouTube"
      >
        <Youtube size={20} />
      </motion.a>
      
      <motion.a
        href="https://telegram.org"
        target="_blank"
        rel="noopener noreferrer"
        whileHover={{ scale: 1.1, y: -2 }}
        whileTap={{ scale: 0.95 }}
        className="p-3 rounded-full bg-sky-500 text-white shadow-lg shadow-sky-500/20 hover:shadow-sky-500/40 transition-all"
        title="Telegram"
      >
        <Send size={20} />
      </motion.a>
      
      <motion.a
        href="https://instagram.com"
        target="_blank"
        rel="noopener noreferrer"
        whileHover={{ scale: 1.1, y: -2 }}
        whileTap={{ scale: 0.95 }}
        className="p-3 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 text-white shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all"
        title="Instagram"
      >
        <Instagram size={20} />
      </motion.a>
    </div>
  );
}
