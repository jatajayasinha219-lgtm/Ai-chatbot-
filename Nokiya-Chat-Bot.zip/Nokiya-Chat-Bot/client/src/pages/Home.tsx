import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/Sidebar";
import LandingPage from "./LandingPage";
import { Loader2 } from "lucide-react";
import { useConversations } from "@/hooks/use-chat";
import { useEffect } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const { isAuthenticated, isLoading } = useAuth();
  const { data: conversations, isLoading: isConversationsLoading } = useConversations();
  const [, setLocation] = useLocation();

  useEffect(() => {
    // If authenticated and has conversations, redirect to most recent chat
    if (isAuthenticated && conversations && conversations.length > 0) {
      // Sort by newest
      const sorted = [...conversations].sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      setLocation(`/chat/${sorted[0].id}`);
    }
  }, [isAuthenticated, conversations, setLocation]);

  if (isLoading || (isAuthenticated && isConversationsLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-primary">
        <Loader2 className="w-10 h-10 animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LandingPage />;
  }

  // If authenticated but no conversations, show empty state with Sidebar
  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />
      <main className="flex-1 flex flex-col items-center justify-center text-center p-8 bg-gradient-to-br from-background via-background to-primary/5">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center shadow-2xl shadow-primary/30 mb-8 animate-float">
          <span className="font-display font-bold text-4xl text-white">AI</span>
        </div>
        <h2 className="text-3xl font-bold mb-4 font-display">Welcome to ID NOKIYA AI</h2>
        <p className="text-muted-foreground max-w-md mb-8">
          Start a new chat to begin. You can generate text, code, images, and upload files.
        </p>
      </main>
    </div>
  );
}
