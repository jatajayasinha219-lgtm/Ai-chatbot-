import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowRight, Bot, Image as ImageIcon, Sparkles, Code2, ShieldCheck, Zap } from "lucide-react";
import { SocialLinks } from "@/components/SocialLinks";

export default function LandingPage() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col">
      {/* Background Gradients */}
      <div className="absolute top-0 left-0 w-full h-[50vh] bg-gradient-to-b from-primary/10 to-transparent pointer-events-none" />
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-purple-500/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Navbar */}
      <nav className="relative z-10 border-b border-white/5 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center shadow-lg shadow-primary/20">
               <Bot className="text-white w-6 h-6" />
             </div>
             <span className="font-display font-bold text-xl tracking-tight text-foreground">ID NOKIYA AI</span>
          </div>
          <Button onClick={handleLogin} className="rounded-full px-6 bg-white text-black hover:bg-white/90">
            Sign In
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="flex-1 relative z-10 flex flex-col items-center justify-center text-center px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm font-medium text-primary mb-8 animate-float">
            <Sparkles size={14} />
            <span>Next Generation AI Assistant</span>
          </span>
          
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight mb-8 bg-clip-text text-transparent bg-gradient-to-b from-white via-white to-white/40 max-w-4xl mx-auto leading-[1.1]">
            Experience the Future <br /> of Conversation
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            Unleash creativity with ID NOKIYA AI. Chat, generate images, write code, and explore ideas with our advanced Gemini-powered assistant.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              onClick={handleLogin} 
              size="lg" 
              className="h-14 px-8 rounded-full text-lg bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-primary/40 hover:-translate-y-1 transition-all duration-300 group"
            >
              Get Started Free
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            
            <Button 
              size="lg" 
              variant="outline" 
              className="h-14 px-8 rounded-full text-lg border-white/10 bg-white/5 hover:bg-white/10 hover:-translate-y-1 transition-all duration-300"
              onClick={() => window.open('https://youtube.com', '_blank')}
            >
              Watch Demo
            </Button>
          </div>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto mt-24">
          <FeatureCard 
            icon={<Bot className="w-8 h-8 text-blue-400" />}
            title="Advanced AI Chat"
            description="Powered by Gemini 1.5 Pro for human-like reasoning and context awareness."
          />
          <FeatureCard 
            icon={<ImageIcon className="w-8 h-8 text-purple-400" />}
            title="Image Generation"
            description="Create stunning visuals from text prompts instantly within your chat."
          />
          <FeatureCard 
            icon={<Code2 className="w-8 h-8 text-green-400" />}
            title="Coding Assistant"
            description="Generate, debug, and explain code in any language with syntax highlighting."
          />
        </div>

        <div className="mt-20">
          <p className="text-sm text-muted-foreground mb-4 font-medium uppercase tracking-wider">Connect With Us</p>
          <SocialLinks />
        </div>
      </main>
      
      {/* Footer */}
      <footer className="border-t border-white/5 py-8 text-center text-sm text-muted-foreground bg-black/20">
        <p>&copy; {new Date().getFullYear()} ID NOKIYA AI. All rights reserved.</p>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="p-8 rounded-3xl bg-white/5 border border-white/5 hover:border-primary/30 hover:bg-white/10 transition-all duration-300 text-left group"
    >
      <div className="mb-4 p-3 rounded-2xl bg-black/20 w-fit group-hover:scale-110 transition-transform duration-300">{icon}</div>
      <h3 className="text-xl font-bold mb-2 font-display">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </motion.div>
  );
}
