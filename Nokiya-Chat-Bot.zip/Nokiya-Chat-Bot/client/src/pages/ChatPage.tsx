import { useRoute } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useConversation } from "@/hooks/use-chat";
import { ChatInterface } from "@/components/ChatInterface";
import { Sidebar } from "@/components/Sidebar";
import { Loader2 } from "lucide-react";
import LandingPage from "./LandingPage";

export default function ChatPage() {
  const [, params] = useRoute("/chat/:id");
  const conversationId = params?.id ? parseInt(params.id) : null;
  const { isAuthenticated, isLoading: isAuthLoading } = useAuth();
  const { data: conversation, isLoading: isChatLoading, error } = useConversation(conversationId);

  if (isAuthLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LandingPage />;
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />
      <main className="flex-1 flex flex-col h-full relative">
        {isChatLoading ? (
          <div className="flex-1 flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : error || !conversation ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <h2 className="text-2xl font-bold mb-2">Chat not found</h2>
            <p className="text-muted-foreground">This conversation may have been deleted.</p>
          </div>
        ) : (
          <ChatInterface 
            key={conversation.id} // Force re-mount on ID change
            conversationId={conversation.id} 
            initialMessages={conversation.messages} 
          />
        )}
      </main>
    </div>
  );
}
