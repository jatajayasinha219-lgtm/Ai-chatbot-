import { z } from 'zod';
import { insertConversationSchema, insertMessageSchema, conversations, messages } from './models/chat';
import { users } from './models/auth';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    getUser: {
      method: 'GET' as const,
      path: '/api/auth/user' as const,
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.internal, // Unauthorized
      },
    },
    logout: {
        method: 'GET' as const,
        path: '/api/logout' as const,
        responses: {}
    }
  },
  conversations: {
    list: {
      method: 'GET' as const,
      path: '/api/conversations' as const,
      responses: {
        200: z.array(z.custom<typeof conversations.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/conversations/:id' as const,
      responses: {
        200: z.custom<typeof conversations.$inferSelect & { messages: typeof messages.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/conversations' as const,
      input: z.object({ title: z.string().optional() }),
      responses: {
        201: z.custom<typeof conversations.$inferSelect>(),
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/conversations/:id' as const,
      responses: {
        204: z.void(),
      },
    },
  },
  messages: {
    create: {
      method: 'POST' as const,
      path: '/api/conversations/:id/messages' as const,
      input: z.object({ content: z.string() }),
      responses: {
        // This endpoint streams responses via SSE, so we don't strictly type the response body here
        200: z.any(), 
      },
    },
  },
  uploads: {
    requestUrl: {
      method: 'POST' as const,
      path: '/api/uploads/request-url' as const,
      input: z.object({
        name: z.string(),
        size: z.number(),
        contentType: z.string(),
      }),
      responses: {
        200: z.object({
          uploadURL: z.string(),
          objectPath: z.string(),
          metadata: z.object({
            name: z.string(),
            size: z.number(),
            contentType: z.string(),
          }),
        }),
      },
    },
  },
    images: {
      generate: {
          method: 'POST' as const,
          path: '/api/generate-image' as const,
          input: z.object({ prompt: z.string() }),
          responses: {
              200: z.object({
                  b64_json: z.string(),
                  mimeType: z.string()
              })
          }
      }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
